#include "amc7836.h"

uint8_t amc7836_speed = DEFAULT_SPEED;
uint8_t amc7836_mode = DEFAULT_MODE;

void AMC7836_Init(void)
{
	amc7836_speed = DEFAULT_SPEED;
	amc7836_mode = DEFAULT_MODE;
	MX_GPIO_Init();
  MX_SPI1_Init(amc7836_speed,amc7836_mode);
}



void AMC7836_Set(uint8_t speedflag, uint8_t modeflag)
{
	MX_SPI1_Init(speedflag,modeflag);
	HAL_Delay(10);
	AMC7836_Read(CHIP_VERSION);
	HAL_Delay(10);
}
uint8_t AMC7836_Read(uint8_t addr)
{
	uint8_t ret;
	ReSetCS_N();
	spi1_read_write_byte(0x80);
	spi1_read_write_byte(addr);
	ret = spi1_read_write_byte(0x00);
	SetCS_N();
	return ret;
}
void AMC7836_Write(uint8_t addr, uint8_t data)
{
	ReSetCS_N();
	spi1_read_write_byte(0x00);
	spi1_read_write_byte(addr);
	spi1_read_write_byte(data);
	SetCS_N();
}


//uint8_t AMC7836_RW(uint8_t RWB, uint16_t addr, uint8_t data)
//{
//	CS_N(0);
//	uint8_t retdata;
//	if(RWB)	//read
//	{
//		addr = addr | 0x8000;
//		spi1_read_write_byte((uint8_t)((addr)>>8));   
//		spi1_read_write_byte((uint8_t)addr);
//		retdata = spi1_read_write_byte(0x00);
//		CS_N(1);
//		return retdata;
//	}
//  else
//	{
//		addr = addr & 0x7fff;
//		spi1_read_write_byte((uint8_t)((addr)>>8));   
//		spi1_read_write_byte((uint8_t)addr);
//		spi1_read_write_byte(data);
//		CS_N(1);
//		return 0;
//	}
//	
//}

