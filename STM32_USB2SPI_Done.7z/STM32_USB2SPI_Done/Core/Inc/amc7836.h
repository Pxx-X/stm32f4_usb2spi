#ifndef __AMC7836_H
#define __AMC7836_H

#include "spi.h"
#include "gpio.h"
//---------------------Address--------------------------
#define	INTERFACE_CONFIG0	0x00
#define	INTERFACE_CONFIG1	0x01
#define	DEVICE_CONFIG0		0x02
#define	CHIPTYPE					0x03
#define CHIP_ID_L					0x04
#define CHIP_ID_H					0x05
#define CHIP_VERSION			0x06

#define MANUFACTURER_ID_L	0x0C
#define MANUFACTURER_ID_H	0x0d

#define	REGISTER_UPDATE		0x0f
#define ADC_CONFIG				0x10
#define FALSE_ALARM_CONFIG	0x11
#define GPIO_CONFIG				0x12
#define ADC_MUX_CONFIG0		0x13
#define ADC_MUX_CONFIG1		0x14
#define ADC_MUX_CONFIG2		0x15

#define DAC_CLEAR_ENABLE0		0x13
#define DAC_CLEAR_ENABLE1		0x14
#define DAC_CLEAR_SOURCE2		0x15
#define DAC_CLEAR_SOURCE2		0x15

#define ALARMOUT_SOURCE0	0x1c
#define ALARMOUT_SOURCE1	0x1d

#define DAC_RANGE0					0x1e
#define DAC_RANGE1					0x1f
#define ADC0_DATA_L					0x20
#define ADC0_DATA_H					0x21
#define ADC1_DATA_L					0x22
#define ADC1_DATA_H					0x23
#define ADC2_DATA_L					0x24
#define ADC2_DATA_H					0x25
#define ADC3_DATA_L					0x26
#define ADC3_DATA_H					0x27
#define ADC4_DATA_L					0x28
#define ADC4_DATA_H					0x29
#define ADC5_DATA_L					0x2a
#define ADC5_DATA_H					0x2b
#define ADC6_DATA_L					0x2c
#define ADC6_DATA_H					0x2d
#define ADC7_DATA_L					0x2e
#define ADC7_DATA_H					0x2f
#define ADC8_DATA_L					0x30
#define ADC8_DATA_H					0x31
#define ADC9_DATA_L					0x32
#define ADC9_DATA_H					0x33
#define ADC10_DATA_L				0x34
#define ADC10_DATA_H				0x35
#define ADC11_DATA_L				0x36
#define ADC11_DATA_H				0x37
#define ADC12_DATA_L				0x38
#define ADC12_DATA_H				0x39
#define ADC13_DATA_L				0x3a
#define ADC13_DATA_H				0x3b
#define ADC14_DATA_L				0x3c
#define ADC14_DATA_H				0x3d
#define ADC15_DATA_L				0x3e
#define ADC15_DATA_H				0x3f
#define ADC16_DATA_L				0x40
#define ADC16_DATA_H				0x41
#define ADC17_DATA_L				0x42
#define ADC17_DATA_H				0x43
#define ADC18_DATA_L				0x44
#define ADC18_DATA_H				0x45
#define ADC19_DATA_L				0x46
#define ADC19_DATA_H				0x47
#define ADC20_DATA_L				0x48
#define ADC20_DATA_H				0x49
#define	TEMP_DATA_L					0x4a
#define TEMP_DATA_H					0x4b

#define DACA0_DATA_L				0x50
#define DACA0_DATA_H				0x51
#define DACA1_DATA_L				0x52
#define DACA1_DATA_H				0x53
#define DACA2_DATA_L				0x54
#define DACA2_DATA_H				0x55
#define DACA3_DATA_L				0x56
#define DACA3_DATA_H				0x57
#define DACB4_DATA_L				0x58
#define DACB4_DATA_H				0x59
#define DACB5_DATA_L				0x5a
#define DACB5_DATA_H				0x5b
#define DACB6_DATA_L				0x5c
#define DACB6_DATA_H				0x5d
#define DACB7_DATA_L				0x5e
#define DACB7_DATA_H				0x5f
#define DACC8_DATA_L				0x60
#define DACC8_DATA_H				0x61
#define DACC9_DATA_L				0x62
#define DACC9_DATA_H				0x63
#define DACC10_DATA_L				0x64
#define DACC10_DATA_H				0x65
#define DACC11_DATA_L				0x66
#define DACC11_DATA_H				0x67
#define DACD12_DATA_L				0x68
#define DACD12_DATA_H				0x69
#define DACD13_DATA_L				0x6a
#define DACD13_DATA_H				0x6b
#define DACD14_DATA_L				0x6c
#define DACD14_DATA_H				0x6d
#define DACD15_DATA_L				0x6e
#define DACD15_DATA_H				0x6f
#define ALARM_STATE0				0x70
#define ALARM_STATE1				0x71
#define GENERAL_STATE				0x72

#define GPIO_								0x7a

#define ADC16_UPPER_THRESH_L	0x80
#define ADC16_UPPER_THRESH_H	0x81
#define ADC16_LOWER_THRESH_L	0x82
#define ADC16_LOWER_THRESH_H	0x83
#define ADC17_UPPER_THRESH_L	0x84
#define ADC17_UPPER_THRESH_H	0x85
#define ADC17_LOWER_THRESH_L	0x86
#define ADC17_LOWER_THRESH_H	0x87
#define ADC18_UPPER_THRESH_L	0x88
#define ADC18_UPPER_THRESH_H	0x89
#define ADC18_LOWER_THRESH_L	0x8a
#define ADC18_LOWER_THRESH_H	0x8b
#define ADC19_UPPER_THRESH_L	0x8c
#define ADC19_UPPER_THRESH_H	0x8d
#define ADC19_LOWER_THRESH_L	0x8e
#define ADC19_LOWER_THRESH_H	0x8f
#define ADC20_UPPER_THRESH_L	0x90
#define ADC20_UPPER_THRESH_H	0x91
#define ADC20_LOWER_THRESH_L	0x92
#define ADC20_LOWER_THRESH_H	0x93
#define	LT_UPPER_THRESH_L			0x94
#define	LT_UPPER_THRESH_H			0x95
#define	LT_LOWER_THRESH_L			0x96
#define	LT_LOWER_THRESH_H			0x97

#define ADC16_HYSTERESIS			0xa0
#define ADC17_HYSTERESIS			0xa1
#define ADC18_HYSTERESIS			0xa2
#define ADC19_HYSTERESIS			0xa3
#define ADC20_HYSTERESIS			0xa4
#define LT_HYSTERESIS					0xa5

#define DAC_CLEAR0						0xb0
#define DAC_CLEAR1						0xb1
#define POWER_DOWN0						0xb2
#define POWER_DOWN1						0xb3
#define POWER_DOWN2						0xb4

#define ADC_TRIGGER						0xc0
                    
//-----------------------------------------------		
#define DEFAULT_SPEED			0x03
#define SPEEDFLAG_41M			0x01	
#define SPEEDFLAG_20d5M		0x02	
#define SPEEDFLAG_10d25M	0x03	
#define SPEEDFLAG_5d125M	0x04	
#define SPEEDFLAG_2d5625M	0x05	
#define SPEEDFLAG_1M			0x06	
#define SPEEDFLAG_0d5M		0x07	
#define SPEEDFLAG_0d25M		0x08			

#define DEFAULT_MODE			0x00
#define MODEFLAG_0				0x00
#define MODEFLAG_1				0x01
#define MODEFLAG_2				0x02
#define MODEFLAG_3				0x03
//-------------------Var----------------------------															
extern uint8_t amc7836_speed;
extern uint8_t amc7836_mode;

//-------------------Func----------------------------															
void AMC7836_Init(void);
void AMC7836_Set(uint8_t speedflag, uint8_t modeflag);

uint8_t AMC7836_Read(uint8_t addr);
void AMC7836_Write(uint8_t addr, uint8_t data);

//uint8_t AMC7836_RW(uint8_t RWB, uint16_t addr, uint8_t data);

#endif

